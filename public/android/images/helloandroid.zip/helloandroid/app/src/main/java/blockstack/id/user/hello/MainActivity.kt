package blockstack.id.user.hello

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.blockstack.android.sdk.BlockstackSession
import org.blockstack.android.sdk.BlockstackSignIn
import org.blockstack.android.sdk.SessionStore
import org.blockstack.android.sdk.getBlockstackSharedPreferences
import org.blockstack.android.sdk.model.UserData
import org.blockstack.android.sdk.model.toBlockstackConfig
import org.blockstack.android.sdk.ui.SignInProvider
import org.blockstack.android.sdk.ui.showBlockstackConnect

class MainActivity : AppCompatActivity(), SignInProvider {

    private lateinit var blockstackSession: BlockstackSession
    private lateinit var blockstackSignIn: BlockstackSignIn

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val appConfig =
            "https://flamboyant-darwin-d11c17.netlify.app".toBlockstackConfig()
        val sessionStore = SessionStore(getBlockstackSharedPreferences())
        blockstackSession = BlockstackSession(sessionStore, appConfig)
        blockstackSignIn = BlockstackSignIn(sessionStore, appConfig)
        BlockstackSignIn.shouldLaunchInCustomTabs = false

        signInButton.setOnClickListener {
            showBlockstackConnect()
        }

        if (intent?.action == Intent.ACTION_VIEW) {
            // handle the redirect from sign in
            userDataTextView.text = "Signing in now ..."
            lifecycleScope.launch(Dispatchers.IO) {
                handleAuthResponse(intent)
            }
        }
    }

    private fun onSignIn(userData: UserData) {
        userDataTextView.text = "Signed in as ${userData.decentralizedID}"
        signInButton.isEnabled = false
    }

    private suspend fun handleAuthResponse(intent: Intent) {
        val authResponse = intent.data?.getQueryParameter("authResponse")
        if (authResponse != null) {
            val userData = blockstackSession.handlePendingSignIn(authResponse)
            if (userData.hasValue) {
                // The user is now signed in!
                runOnUiThread {
                    onSignIn(userData.value!!)
                }
            }
        }
    }

    override fun provideBlockstackSignIn(): BlockstackSignIn {
        return blockstackSignIn
    }

}
